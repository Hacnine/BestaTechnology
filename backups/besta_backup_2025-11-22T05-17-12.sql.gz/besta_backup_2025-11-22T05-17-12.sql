/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: audit_logs
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userRole` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resourceId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipAddress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userAgent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: buyers
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `buyers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buyerDepartmentId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `buyers_buyerDepartmentId_fkey` (`buyerDepartmentId`),
  CONSTRAINT `buyers_buyerDepartmentId_fkey` FOREIGN KEY (`buyerDepartmentId`) REFERENCES `departments` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: cad_designs
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `cad_designs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdById` int DEFAULT NULL,
  `fileReceiveDate` datetime(3) DEFAULT NULL,
  `completeDate` datetime(3) DEFAULT NULL,
  `CadMasterName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalFileReceivedDate` datetime(3) DEFAULT NULL,
  `finalCompleteDate` datetime(3) DEFAULT NULL,
  `tnaId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cad_designs_createdById_fkey` (`createdById`),
  KEY `cad_designs_tnaId_fkey` (`tnaId`),
  CONSTRAINT `cad_designs_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `cad_designs_tnaId_fkey` FOREIGN KEY (`tnaId`) REFERENCES `tnas` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 5 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: cost_sheets
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `cost_sheets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `styleId` int NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fabricType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gsm` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `buyer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `styleRows` json DEFAULT NULL,
  `cadRows` json NOT NULL,
  `fabricRows` json NOT NULL,
  `trimsRows` json NOT NULL,
  `othersRows` json NOT NULL,
  `summaryRows` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cost_sheets_styleId_fkey` (`styleId`),
  KEY `cost_sheets_createdById_fkey` (`createdById`),
  CONSTRAINT `cost_sheets_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `cost_sheets_styleId_fkey` FOREIGN KEY (`styleId`) REFERENCES `styles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: departments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: dhl_trackings
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `dhl_trackings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` datetime(3) NOT NULL,
  `tnaId` int DEFAULT NULL,
  `trackingNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isComplete` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dhl_trackings_tnaId_fkey` (`tnaId`),
  CONSTRAINT `dhl_trackings_tnaId_fkey` FOREIGN KEY (`tnaId`) REFERENCES `tnas` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: employees
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE', 'INACTIVE', 'PENDING', 'SUSPENDED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` enum(
  'MERCHANDISING',
  'MANAGEMENT',
  'IT',
  'CAD_ROOM',
  'SAMPLE_FABRIC',
  'SAMPLE_SEWING'
  ) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_customId_key` (`customId`),
  UNIQUE KEY `employees_email_key` (`email`)
) ENGINE = InnoDB AUTO_INCREMENT = 7 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: fabric_bookings
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `fabric_bookings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdById` int DEFAULT NULL,
  `receiveDate` datetime(3) DEFAULT NULL,
  `completeDate` datetime(3) DEFAULT NULL,
  `actualCompleteDate` datetime(3) DEFAULT NULL,
  `tnaId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fabric_bookings_createdById_fkey` (`createdById`),
  KEY `fabric_bookings_tnaId_fkey` (`tnaId`),
  CONSTRAINT `fabric_bookings_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `fabric_bookings_tnaId_fkey` FOREIGN KEY (`tnaId`) REFERENCES `tnas` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: sample_developments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sample_developments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdById` int DEFAULT NULL,
  `samplemanName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sampleReceiveDate` datetime(3) DEFAULT NULL,
  `sampleCompleteDate` datetime(3) DEFAULT NULL,
  `actualSampleCompleteDate` datetime(3) DEFAULT NULL,
  `tnaId` int DEFAULT NULL,
  `sampleQuantity` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sample_developments_createdById_fkey` (`createdById`),
  KEY `sample_developments_tnaId_fkey` (`tnaId`),
  CONSTRAINT `sample_developments_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `sample_developments_tnaId_fkey` FOREIGN KEY (`tnaId`) REFERENCES `tnas` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: styles
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `styles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: tnas
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `tnas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createdById` int DEFAULT NULL,
  `buyerId` int DEFAULT NULL,
  `style` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `itemName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `itemImage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sampleSendingDate` datetime(3) NOT NULL,
  `orderDate` datetime(3) NOT NULL,
  `status` enum('ACTIVE', 'CANCELLED', 'INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `sampleType` enum('DVP', 'PP1', 'PP2', 'PP3', 'PP4', 'PP5') COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tnas_createdById_fkey` (`createdById`),
  KEY `tnas_buyerId_fkey` (`buyerId`),
  KEY `tnas_userId_fkey` (`userId`),
  CONSTRAINT `tnas_buyerId_fkey` FOREIGN KEY (`buyerId`) REFERENCES `buyers` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `tnas_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `tnas_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: trims_and_accessories
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `trims_and_accessories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trimsRows` json NOT NULL,
  `createdById` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `trims_and_accessories_createdById_fkey` (`createdById`),
  CONSTRAINT `trims_and_accessories_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: users
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum(
  'ADMIN',
  'MANAGEMENT',
  'MERCHANDISER',
  'CAD',
  'SAMPLE_FABRIC',
  'SAMPLE_ROOM'
  ) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employeeId` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_userName_key` (`userName`),
  UNIQUE KEY `users_employeeId_key` (`employeeId`),
  CONSTRAINT `users_employeeId_fkey` FOREIGN KEY (`employeeId`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 7 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: audit_logs
# ------------------------------------------------------------

INSERT INTO
  `audit_logs` (
    `id`,
    `timestamp`,
    `user`,
    `userRole`,
    `action`,
    `resource`,
    `resourceId`,
    `description`,
    `ipAddress`,
    `userAgent`,
    `status`
  )
VALUES
  (
    1,
    '2025-11-17 11:20:58.616',
    'admin',
    'ADMIN',
    'seed',
    'seed',
    '1',
    'Initial seed data created',
    '127.0.0.1',
    'seed-script',
    'SUCCESS'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: buyers
# ------------------------------------------------------------

INSERT INTO
  `buyers` (`id`, `name`, `country`, `buyerDepartmentId`)
VALUES
  (1, 'Seed Buyer', 'Local', NULL);

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: cad_designs
# ------------------------------------------------------------

INSERT INTO
  `cad_designs` (
    `id`,
    `createdById`,
    `fileReceiveDate`,
    `completeDate`,
    `CadMasterName`,
    `finalFileReceivedDate`,
    `finalCompleteDate`,
    `tnaId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    4,
    '2025-11-18 08:34:26.643',
    '2025-11-20 08:34:26.643',
    'caduser',
    NULL,
    '2025-11-18 08:34:31.263',
    2,
    '2025-11-18 06:41:44.690',
    '2025-11-18 08:34:31.265'
  );
INSERT INTO
  `cad_designs` (
    `id`,
    `createdById`,
    `fileReceiveDate`,
    `completeDate`,
    `CadMasterName`,
    `finalFileReceivedDate`,
    `finalCompleteDate`,
    `tnaId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    4,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-11-20 04:39:37.453',
    '2025-11-20 04:39:37.453'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: cost_sheets
# ------------------------------------------------------------

INSERT INTO
  `cost_sheets` (
    `id`,
    `styleId`,
    `item`,
    `group`,
    `size`,
    `fabricType`,
    `gsm`,
    `color`,
    `quantity`,
    `buyer`,
    `brand`,
    `image`,
    `createdById`,
    `name`,
    `createdAt`,
    `updatedAt`,
    `styleRows`,
    `cadRows`,
    `fabricRows`,
    `trimsRows`,
    `othersRows`,
    `summaryRows`
  )
VALUES
  (
    1,
    1,
    'Seed Item',
    'General',
    'M',
    'Cotton',
    '180',
    'Blue',
    100,
    NULL,
    NULL,
    NULL,
    1,
    'Seed CostSheet',
    '2025-11-17 11:20:58.501',
    '2025-11-17 11:20:58.501',
    NULL,
    '[]',
    '[]',
    '[]',
    '[]',
    '{}'
  );
INSERT INTO
  `cost_sheets` (
    `id`,
    `styleId`,
    `item`,
    `group`,
    `size`,
    `fabricType`,
    `gsm`,
    `color`,
    `quantity`,
    `buyer`,
    `brand`,
    `image`,
    `createdById`,
    `name`,
    `createdAt`,
    `updatedAt`,
    `styleRows`,
    `cadRows`,
    `fabricRows`,
    `trimsRows`,
    `othersRows`,
    `summaryRows`
  )
VALUES
  (
    2,
    2,
    'Baby Jogging tops',
    'Boys',
    'xs-3xl',
    'Fleece, 85% Cotton 15% Polyester',
    '320',
    '01X',
    90,
    '',
    'Hico',
    NULL,
    3,
    'Test Fess',
    '2025-11-18 09:20:56.983',
    '2025-11-18 09:21:40.308',
    '{\"rows\": []}',
    '{\"json\": {\"rows\": [{\"value\": 7.419999999999999, \"weight\": \"6.999999999999999\", \"percent\": \"6\", \"fieldName\": \"Body\"}, {\"value\": 6, \"weight\": \"6\", \"percent\": \"\", \"fieldName\": \"Rib\"}, {\"value\": 6, \"weight\": \"6\", \"percent\": \"\", \"fieldName\": \"SJ-NT, Lining\"}, {\"value\": 0, \"weight\": \"\", \"percent\": \"\", \"fieldName\": \"Contrast Body\"}], \"columns\": [\"Field Name\", \"Weight (kg / yard)\", \"With %\", \"Fabric Consumption\"], \"tableName\": \"CAD Consumption / Dz\", \"totalValue\": 19.42, \"totalWeight\": 19}, \"rows\": [{\"id\": \"cad-1763457671529-0\", \"value\": 7.419999999999999, \"weight\": \"6.999999999999999\", \"percent\": \"6\", \"fieldName\": \"Body\"}, {\"id\": \"cad-1763457671529-1\", \"value\": 6, \"weight\": \"6\", \"percent\": \"\", \"fieldName\": \"Rib\"}, {\"id\": \"cad-1763457671529-2\", \"value\": 6, \"weight\": \"6\", \"percent\": \"\", \"fieldName\": \"SJ-NT, Lining\"}, {\"id\": \"cad-1763457671529-3\", \"value\": 0, \"weight\": \"\", \"percent\": \"\", \"fieldName\": \"Contrast Body\"}]}',
    '{\"json\": {\"yarnRows\": [{\"id\": \"yarn-1\", \"rate\": \"\", \"unit\": \"7.420\", \"value\": 0, \"fieldName\": \"30/1, 100% Cotton\"}, {\"id\": \"yarn-2\", \"rate\": \"\", \"unit\": \"6.000\", \"value\": 0, \"fieldName\": \"20/1, 100% Cotton\"}, {\"id\": \"cad-2\", \"rate\": \"\", \"unit\": \"6.000\", \"value\": 0, \"fieldName\": \"SJ-NT, Lining\"}, {\"id\": \"cad-3\", \"rate\": \"\", \"unit\": \"0.000\", \"value\": 0, \"fieldName\": \"Contrast Body\"}], \"tableName\": \"Fabric Cost\", \"yarnTotal\": 0, \"dyeingRows\": [{\"id\": \"dye-1\", \"rate\": \"6\", \"unit\": \"6\", \"value\": 36, \"fieldName\": \"Avarage Color shade\"}, {\"id\": \"dye-2\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Peach\"}, {\"id\": \"dye-3\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Brush\"}, {\"id\": \"dye-4\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Peach & Brush\"}, {\"id\": \"dye-5\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Heat set\"}], \"dyeingTotal\": 36, \"knittingRows\": [{\"id\": \"knit-1\", \"rate\": \"\", \"unit\": \"7.419999999999999\", \"value\": 0, \"fieldName\": \"F. Terry\"}, {\"id\": \"knit-2\", \"rate\": \"\", \"unit\": \"6\", \"value\": 0, \"fieldName\": \"Rib\"}, {\"id\": \"knit-3\", \"rate\": \"\", \"unit\": \"6\", \"value\": 0, \"fieldName\": \"SJ\"}, {\"id\": \"cad-3\", \"rate\": \"\", \"unit\": \"0\", \"value\": 0, \"fieldName\": \"Contrast Body\"}], \"knittingTotal\": 0, \"totalFabricCost\": 36}, \"rows\": {\"yarnRows\": [{\"id\": \"yarn-1\", \"rate\": \"\", \"unit\": \"7.420\", \"value\": 0, \"fieldName\": \"30/1, 100% Cotton\"}, {\"id\": \"yarn-2\", \"rate\": \"\", \"unit\": \"6.000\", \"value\": 0, \"fieldName\": \"20/1, 100% Cotton\"}, {\"id\": \"cad-2\", \"rate\": \"\", \"unit\": \"6.000\", \"value\": 0, \"fieldName\": \"SJ-NT, Lining\"}, {\"id\": \"cad-3\", \"rate\": \"\", \"unit\": \"0.000\", \"value\": 0, \"fieldName\": \"Contrast Body\"}], \"dyeingRows\": [{\"id\": \"dye-1\", \"rate\": \"6\", \"unit\": \"6\", \"value\": 36, \"fieldName\": \"Avarage Color shade\"}, {\"id\": \"dye-2\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Peach\"}, {\"id\": \"dye-3\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Brush\"}, {\"id\": \"dye-4\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Peach & Brush\"}, {\"id\": \"dye-5\", \"rate\": \"\", \"unit\": \"\", \"value\": 0, \"fieldName\": \"Heat set\"}], \"knittingRows\": [{\"id\": \"knit-1\", \"rate\": \"\", \"unit\": \"7.419999999999999\", \"value\": 0, \"fieldName\": \"F. Terry\"}, {\"id\": \"knit-2\", \"rate\": \"\", \"unit\": \"6\", \"value\": 0, \"fieldName\": \"Rib\"}, {\"id\": \"knit-3\", \"rate\": \"\", \"unit\": \"6\", \"value\": 0, \"fieldName\": \"SJ\"}, {\"id\": \"cad-3\", \"rate\": \"\", \"unit\": \"0\", \"value\": 0, \"fieldName\": \"Contrast Body\"}]}}',
    '{\"rows\": [{\"cost\": \"6\", \"unit\": \"612\", \"total\": 3672, \"description\": \"\"}], \"columns\": [\"Item Description\", \"Unit\", \"Rate\", \"Total\"], \"subtotal\": 3672, \"tableName\": \"Trims & Accessories\", \"totalAccessoriesCost\": 3672}',
    '{\"rows\": [{\"id\": \"other-1\", \"label\": \"AOP\", \"value\": \"6\"}, {\"id\": \"other-2\", \"label\": \"Screen print\", \"value\": \"\"}, {\"id\": \"other-3\", \"label\": \"Embroidery\", \"value\": \"\"}, {\"id\": \"other-4\", \"label\": \"Wash\", \"value\": \"\"}], \"total\": 6, \"columns\": [\"Label\", \"Value\"], \"tableName\": \"Others\"}',
    '{\"json\": {\"factoryCM\": 67, \"tableName\": \"Summary\", \"pricePerPiece\": \"762.974\", \"profitPercent\": 67, \"commercialPercent\": 45}, \"summary\": {\"factoryCM\": 67, \"pricePerPiece\": \"762.974\", \"profitPercent\": 67, \"commercialPercent\": 45}}'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: departments
# ------------------------------------------------------------

INSERT INTO
  `departments` (`id`, `name`, `contactPerson`)
VALUES
  (1, 'IT Department', 'Seed Contact');

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: dhl_trackings
# ------------------------------------------------------------

INSERT INTO
  `dhl_trackings` (
    `id`,
    `date`,
    `tnaId`,
    `trackingNumber`,
    `isComplete`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    '2025-11-17 11:20:58.596',
    NULL,
    'SEEDTRACK123',
    0,
    '2025-11-17 11:20:58.597',
    '2025-11-17 11:20:58.597'
  );
INSERT INTO
  `dhl_trackings` (
    `id`,
    `date`,
    `tnaId`,
    `trackingNumber`,
    `isComplete`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    '2025-11-18 00:00:00.000',
    NULL,
    '88888',
    1,
    '2025-11-18 09:43:32.692',
    '2025-11-18 09:43:32.692'
  );
INSERT INTO
  `dhl_trackings` (
    `id`,
    `date`,
    `tnaId`,
    `trackingNumber`,
    `isComplete`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    3,
    '2025-11-18 00:00:00.000',
    NULL,
    't56556',
    1,
    '2025-11-18 09:44:29.644',
    '2025-11-18 09:44:29.644'
  );
INSERT INTO
  `dhl_trackings` (
    `id`,
    `date`,
    `tnaId`,
    `trackingNumber`,
    `isComplete`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    4,
    '2025-11-18 00:00:00.000',
    2,
    '55',
    1,
    '2025-11-18 10:29:03.848',
    '2025-11-18 10:35:28.098'
  );
INSERT INTO
  `dhl_trackings` (
    `id`,
    `date`,
    `tnaId`,
    `trackingNumber`,
    `isComplete`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    5,
    '2025-11-25 00:00:00.000',
    NULL,
    '',
    0,
    '2025-11-20 04:39:37.475',
    '2025-11-20 04:39:37.475'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: employees
# ------------------------------------------------------------

INSERT INTO
  `employees` (
    `id`,
    `customId`,
    `name`,
    `email`,
    `phoneNumber`,
    `status`,
    `designation`,
    `department`
  )
VALUES
  (
    1,
    'EMP001',
    'Admin',
    'admin@tna.com',
    NULL,
    'ACTIVE',
    'System Administrator',
    'IT'
  );
INSERT INTO
  `employees` (
    `id`,
    `customId`,
    `name`,
    `email`,
    `phoneNumber`,
    `status`,
    `designation`,
    `department`
  )
VALUES
  (
    2,
    'EMP_SEED_MANAGER',
    'manager',
    'manager@tna.local',
    NULL,
    'ACTIVE',
    'MANAGEMENT',
    'MERCHANDISING'
  );
INSERT INTO
  `employees` (
    `id`,
    `customId`,
    `name`,
    `email`,
    `phoneNumber`,
    `status`,
    `designation`,
    `department`
  )
VALUES
  (
    3,
    'EMP_SEED_MERCH',
    'merch',
    'merch@tna.local',
    NULL,
    'ACTIVE',
    'MERCHANDISER',
    'MERCHANDISING'
  );
INSERT INTO
  `employees` (
    `id`,
    `customId`,
    `name`,
    `email`,
    `phoneNumber`,
    `status`,
    `designation`,
    `department`
  )
VALUES
  (
    4,
    'EMP_SEED_CAD',
    'caduser',
    'cad@tna.local',
    NULL,
    'ACTIVE',
    'CAD',
    'MERCHANDISING'
  );
INSERT INTO
  `employees` (
    `id`,
    `customId`,
    `name`,
    `email`,
    `phoneNumber`,
    `status`,
    `designation`,
    `department`
  )
VALUES
  (
    5,
    'EMP_SEED_SAMPLEFAB',
    'samplefab',
    'samplefab@tna.local',
    NULL,
    'ACTIVE',
    'SAMPLE_FABRIC',
    'MERCHANDISING'
  );
INSERT INTO
  `employees` (
    `id`,
    `customId`,
    `name`,
    `email`,
    `phoneNumber`,
    `status`,
    `designation`,
    `department`
  )
VALUES
  (
    6,
    'EMP_SEED_SAMPLEROOM',
    'sampleroom',
    'sampleroom@tna.local',
    NULL,
    'ACTIVE',
    'SAMPLE_ROOM',
    'MERCHANDISING'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: fabric_bookings
# ------------------------------------------------------------

INSERT INTO
  `fabric_bookings` (
    `id`,
    `createdById`,
    `receiveDate`,
    `completeDate`,
    `actualCompleteDate`,
    `tnaId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    1,
    '2025-11-17 11:20:58.552',
    '2025-12-02 11:20:58.552',
    NULL,
    NULL,
    '2025-11-17 11:20:58.553',
    '2025-11-17 11:20:58.553'
  );
INSERT INTO
  `fabric_bookings` (
    `id`,
    `createdById`,
    `receiveDate`,
    `completeDate`,
    `actualCompleteDate`,
    `tnaId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    5,
    '2025-11-18 08:33:18.718',
    '2025-12-03 08:33:18.718',
    '2025-11-18 08:33:30.820',
    2,
    '2025-11-18 06:41:44.706',
    '2025-11-18 08:33:30.821'
  );
INSERT INTO
  `fabric_bookings` (
    `id`,
    `createdById`,
    `receiveDate`,
    `completeDate`,
    `actualCompleteDate`,
    `tnaId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    5,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-11-20 04:39:37.461',
    '2025-11-20 04:39:37.461'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: sample_developments
# ------------------------------------------------------------

INSERT INTO
  `sample_developments` (
    `id`,
    `createdById`,
    `samplemanName`,
    `sampleReceiveDate`,
    `sampleCompleteDate`,
    `actualSampleCompleteDate`,
    `tnaId`,
    `sampleQuantity`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    1,
    'Seed Sample',
    NULL,
    NULL,
    '2025-11-18 08:28:10.105',
    NULL,
    10,
    '2025-11-17 11:20:58.576',
    '2025-11-18 08:28:10.107'
  );
INSERT INTO
  `sample_developments` (
    `id`,
    `createdById`,
    `samplemanName`,
    `sampleReceiveDate`,
    `sampleCompleteDate`,
    `actualSampleCompleteDate`,
    `tnaId`,
    `sampleQuantity`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    NULL,
    'SF',
    '2025-11-18 08:36:07.457',
    '2025-11-20 08:36:07.457',
    '2025-11-18 08:36:18.032',
    2,
    2,
    '2025-11-18 06:41:44.720',
    '2025-11-18 08:36:18.033'
  );
INSERT INTO
  `sample_developments` (
    `id`,
    `createdById`,
    `samplemanName`,
    `sampleReceiveDate`,
    `sampleCompleteDate`,
    `actualSampleCompleteDate`,
    `tnaId`,
    `sampleQuantity`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    5,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-11-20 04:39:37.468',
    '2025-11-20 04:39:37.468'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: styles
# ------------------------------------------------------------

INSERT INTO
  `styles` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    1,
    'Seed Style',
    '2025-11-17 11:20:58.440',
    '2025-11-17 11:20:58.440'
  );
INSERT INTO
  `styles` (`id`, `name`, `createdAt`, `updatedAt`)
VALUES
  (
    2,
    'hj-90900',
    '2025-11-18 09:20:56.938',
    '2025-11-18 09:20:56.938'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: tnas
# ------------------------------------------------------------

INSERT INTO
  `tnas` (
    `id`,
    `createdById`,
    `buyerId`,
    `style`,
    `itemName`,
    `itemImage`,
    `sampleSendingDate`,
    `orderDate`,
    `status`,
    `sampleType`,
    `userId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    3,
    1,
    '685hr',
    't-Shirt',
    '/uploads/images/1763448103654-Screenshot 2025-11-17 123251.png',
    '2025-11-28 00:00:00.000',
    '2025-11-18 00:00:00.000',
    'ACTIVE',
    'DVP',
    3,
    '2025-11-18 06:41:44.546',
    '2025-11-18 06:41:44.546'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: trims_and_accessories
# ------------------------------------------------------------

INSERT INTO
  `trims_and_accessories` (
    `id`,
    `name`,
    `trimsRows`,
    `createdById`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    'Seed Trims',
    '{\"items\": [{\"qty\": 10, \"name\": \"Button\"}]}',
    1,
    '2025-11-17 11:20:58.529',
    '2025-11-17 11:20:58.529'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: users
# ------------------------------------------------------------

INSERT INTO
  `users` (`id`, `userName`, `password`, `role`, `employeeId`)
VALUES
  (
    1,
    'admin',
    '$2b$10$S8gSx63yOJtlYaXpHwaXcOxQ0uUtq.oa78vRF7xNLu/47Rp6OWmAu',
    'ADMIN',
    1
  );
INSERT INTO
  `users` (`id`, `userName`, `password`, `role`, `employeeId`)
VALUES
  (
    2,
    'manager',
    '$2b$10$OCkDFVm43zykbSKVz8zuKuqmWvcA8zRD0vG94W0S2bLOOiMcXOLJi',
    'MANAGEMENT',
    2
  );
INSERT INTO
  `users` (`id`, `userName`, `password`, `role`, `employeeId`)
VALUES
  (
    3,
    'merch',
    '$2b$10$tp1zTbu5yVUmsqQewahVY.Er6tepfwclg1oFj7gIso36TssIvj9C.',
    'MERCHANDISER',
    3
  );
INSERT INTO
  `users` (`id`, `userName`, `password`, `role`, `employeeId`)
VALUES
  (
    4,
    'caduser',
    '$2b$10$nWUtn9PXhp5Lr.t44xjmB.RZyKzxnM5J5ebsI7iSYT1GxvReb2xGa',
    'CAD',
    4
  );
INSERT INTO
  `users` (`id`, `userName`, `password`, `role`, `employeeId`)
VALUES
  (
    5,
    'samplefab',
    '$2b$10$G2KWf9W8orL679IW3aybt.zS6XdCA6YrHowMMTEzfsRfcoXK6MGW6',
    'SAMPLE_FABRIC',
    5
  );
INSERT INTO
  `users` (`id`, `userName`, `password`, `role`, `employeeId`)
VALUES
  (
    6,
    'sampleroom',
    '$2b$10$qGaTeV3eOL5gYZgnxrvYBOTkqA9dj2wLuW3lYO.jriNRTkiaOsNYe',
    'SAMPLE_ROOM',
    6
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
